#include "array.h"

// Class constructor
array_t::array_t() :
    ptr(0),
    num_elements(0),
    array_size(0) {
}


/* Assignment 1:
   Write a copy constructor and destructor of the class,
   and complete reserve() and push_back() functions.
  */


// Allocate a memory space for the specified number of elements.
void array_t::reserve(const size_t m_array_size) {

}

// Add a new element at the end of array.
void array_t::push_back(const data_t m_value) {

}

