#ifndef __VECTOR_HPP__
#define __VECTOR_HPP__

#include <cstdlib>
#include <new>

// Constructor
template <typename T>
vector_t<T>::vector_t(void) :
    array(0),
    array_size(0),
    num_elements(0) {
    // Nothing to do
}

// Copy constructor
template <typename T>
vector_t<T>::vector_t(const vector_t<T> &m_vector) :
    array(0),
    array_size(m_vector.num_elements),
    num_elements(m_vector.num_elements) {
    // Copy constructor creates a copy of tight-fit array.
    array = (T*)malloc(sizeof(T) * array_size);
    for(size_t i = 0; i < num_elements; i++) {
        new (&array[i]) T(m_vector.array[i]);
    }
}

// Destructor
template <typename T>
vector_t<T>::~vector_t(void) {
    // Destruct all elements first, and then free the array.
    for(size_t i = 0; i < num_elements; i++) { array[i].~T(); }
    free(array);
}

// Get the number of elements in the array.
template <typename T>
inline size_t vector_t<T>::size(void) const { return num_elements; }

// Get the allocated size of array in unit of elements.
template <typename T>
inline size_t vector_t<T>::capacity(void) const { return array_size; }

// Get a reference of element at the given index.
template <typename T>
inline T& vector_t<T>::operator[](const size_t m_index) const { return array[m_index]; }

// Get an iterator pointing to the first element of array.
template <typename T>
inline typename vector_t<T>::iterator vector_t<T>::begin(void) const {
    return iterator_t<T>(array);
}

// Get an iterator pointing to the next of last element.
template <typename T>
inline typename vector_t<T>::iterator vector_t<T>::end(void) const {
    return iterator_t<T>(array+num_elements);
}





/*************************
 * EEE5501: Assignment 2 *
 *************************/

// Reserve an array space for the given number of elements.
template <typename T>
void vector_t<T>::reserve(size_t m_array_size) {
    /* Assignment */
}

// Remove all elements in the array.
template <typename T>
void vector_t<T>::clear(void) {
    /* Assignment */
}

// Add a new element at the end of array.
template <typename T>
void vector_t<T>::push_back(const T &m_data) {
    /* Assignment */
}

// Remove the last element in the array.
template <typename T>
void vector_t<T>::pop_back(void) {
    /* Assignment */
}

// Assign new contents to the array.
template <typename T>
vector_t<T>& vector_t<T>::operator=(const vector_t<T> &m_vector) {
    /* Assignment */
    return *this;
}

// Add a new element at the location pointed by the iterator.
template <typename T>
typename vector_t<T>::iterator vector_t<T>::insert(vector_t<T>::iterator m_it,
                                                   const T &m_data) {
    /* Assignment */
    return iterator_t<T>(0);
}

// Erase an element at the location pointed by the iterator.
template <typename T>
typename vector_t<T>::iterator vector_t<T>::erase(vector_t<T>::iterator m_it) {
    /* Assignment */
    return iterator_t<T>(0);
}

/*********************
 * End of Assignment *
 *********************/

#endif

